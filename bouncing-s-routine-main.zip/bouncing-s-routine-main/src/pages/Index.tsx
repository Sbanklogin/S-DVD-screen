import BouncingS from "@/components/BouncingS";

const Index = () => {
  return (
    <div className="w-screen h-screen">
      <BouncingS />
    </div>
  );
};

export default Index;