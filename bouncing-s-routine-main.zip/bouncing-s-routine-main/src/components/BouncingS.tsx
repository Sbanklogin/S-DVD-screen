import React, { useEffect, useRef, useState } from 'react';

const BouncingS = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [velocity, setVelocity] = useState({ x: 3, y: 2 });
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const logoSize = { width: 100, height: 100 };
  const frameRef = useRef<number>();

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);

    return () => {
      window.removeEventListener('resize', updateDimensions);
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const animate = () => {
      setPosition((prev) => {
        const newX = prev.x + velocity.x;
        const newY = prev.y + velocity.y;

        let newVelX = velocity.x;
        let newVelY = velocity.y;

        // Avoid corners by changing direction slightly before hitting them
        const cornerBuffer = 50;
        if (
          (newX <= cornerBuffer && newY <= cornerBuffer) ||
          (newX <= cornerBuffer && newY >= dimensions.height - logoSize.height - cornerBuffer) ||
          (newX >= dimensions.width - logoSize.width - cornerBuffer && newY <= cornerBuffer) ||
          (newX >= dimensions.width - logoSize.width - cornerBuffer && newY >= dimensions.height - logoSize.height - cornerBuffer)
        ) {
          newVelX = velocity.x * (0.8 + Math.random() * 0.4);
          newVelY = velocity.y * (0.8 + Math.random() * 0.4);
        }

        // Bounce off walls
        if (newX <= 0 || newX >= dimensions.width - logoSize.width) {
          newVelX = -velocity.x;
        }
        if (newY <= 0 || newY >= dimensions.height - logoSize.height) {
          newVelY = -velocity.y;
        }

        if (newVelX !== velocity.x || newVelY !== velocity.y) {
          setVelocity({ x: newVelX, y: newVelY });
        }

        return {
          x: Math.max(0, Math.min(newX, dimensions.width - logoSize.width)),
          y: Math.max(0, Math.min(newY, dimensions.height - logoSize.height)),
        };
      });

      frameRef.current = requestAnimationFrame(animate);
    };

    if (dimensions.width && dimensions.height) {
      frameRef.current = requestAnimationFrame(animate);
    }

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, [dimensions, velocity]);

  return (
    <div ref={containerRef} className="w-full h-full relative bg-[#1A1F2C] overflow-hidden">
      <div
        className="absolute text-8xl font-bold animate-color-shift select-none"
        style={{
          transform: `translate(${position.x}px, ${position.y}px)`,
        }}
      >
        S
      </div>
    </div>
  );
};

export default BouncingS;